Required:
- SBCL
- Quicklisp: /home/quicklisp/setup.lisp

